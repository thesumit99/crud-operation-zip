import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addingHandler } from '../store/action/acton';
import { Formik, ErrorMessage, Field, Form } from 'formik'
import * as Yup from 'yup'
import { useHistory } from 'react-router-dom';

const AddData = () => {

    let dispatch = useDispatch()
    let history = useHistory();

    const formInitvalues = {
        name: '',
        desc: '',
        id: '',
    }


    const submitHandler = (formValues) => {
        console.log("*********", formValues);
        dispatch(addingHandler(formValues))
        history.push("/")

    }

    const validSchema = Yup.object().shape({
        name: Yup.string().required(),
        desc: Yup.string().required(),
        id: Yup.number().required()
    })

    return (
        <div className="container mt-5">
            <Formik
                onSubmit={submitHandler}
                initialValues={formInitvalues}
                validationSchema={validSchema}>
                <Form>
                    <h2 className="mb-5" style={{ fontFamily:'serif' , color:'indianred' }}>Add Users</h2>
                    <div className="form-group">
                        <label htmlFor="">Name</label>
                        <Field type="text" name="name" id="" className="form-control" />
                        <ErrorMessage name="name" className="text-danger" component="span" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">desc</label>
                        <Field type="textarea" name="desc" id="" className="form-control" />
                        <ErrorMessage name="desc" className="text-danger" component="span" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">id</label>
                        <Field type="text" name="id" id="" className="form-control" />
                        <ErrorMessage name="id" className="text-danger" component="span" />
                    </div>

                    <div className="form-group">
                        <button type="submit" className="btn btn-primary">Create</button>
                    </div>
                </Form>
            </Formik>
        </div>
    )
}

export default AddData
