import { combineReducers } from "redux"
import { reducerHandler } from "./reducerHandler"

export const rootReducer = combineReducers({
    reducerHandler
});