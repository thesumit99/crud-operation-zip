import React from 'react'

const Try = () => {
    return (
        <div>
            <h1>sumit</h1>
        </div>
    )
}

export default Try
