import { act } from "react-dom/cjs/react-dom-test-utils.production.min";
import { FakeData } from "./../../components/FakeData"

const initialState = {
    value: FakeData
}
export const reducerHandler = (state = initialState, action) => {
    switch (action.type) {
        case "DELETE":
            console.log("trueee");
            console.log("==>", action.payload);
            let myFun = state.value;
            console.log(myFun);
            let newArr = myFun.filter((data) => {
                return data.id != action.payload
            })
            console.log("//", newArr);
            console.log(">>>>>>>>>>>>", { ...state, value: newArr });
            return { state, value: newArr }
        case "ADD":
            console.log("adding");
            console.log(action.payload);
            state.value.push(action.payload)
            console.log("2222", state);
            return state;
        case "UPDATE":
            console.log("--updatinggg--", action.payload.id);
            let arr = state.value
            arr.map((data) => {
                switch (data.id) {
                    case action.payload.id:
                        console.log("truu");
                        console.log(action.payload.id);
                        arr[action.payload.id - 1] = {
                            name: action.payload.name,
                            desc: action.payload.desc,
                            id: action.payload.id
                        }
                        return state
                    default:
                        return state

                }
            })
            return state
        default:
            console.log("falseee");
            return state;
    }
}