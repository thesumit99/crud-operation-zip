import React, { useEffect, useState } from 'react'
import { Formik, Field, ErrorMessage, Form } from 'formik';
import * as Yup from "yup"
import { useHistory, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { updatingDataHandler } from '../store/action/acton';


const UpdateData = () => {
    let params = useParams();
    const history = useHistory();
    console.log(params.id);
    let myState = useSelector(state => state.reducerHandler.value)
    const dispatch = useDispatch();


    const [initialFormValues, setInitialFormValues] = useState({
        name: '',
        desc: '',
        id: '',
    });

    useEffect(() => {
        getRecord();
    }, []);

    const getRecord = () => {
        let newArr = myState.filter((data) => {
            return data.id == params.id
        })
        console.log("''''''", newArr);
        newArr.map((val) => {
            return (
                <div>
                    {
                        setInitialFormValues({
                            name: val.name,
                            desc: val.desc,
                            id: val.id
                        })
                    }
                </div>
            );
        })

    }

    const validScehma = Yup.object().shape({
        name: Yup.string().required(),
        desc: Yup.string().required(),
        id: Yup.number().required()
    });

    const submitHandler = (formValues) => {
        console.log(formValues);
        dispatch(updatingDataHandler(formValues))
        history.push("/")

    }

    return (
        <div className="container mt-5">
            <Formik
                onSubmit={submitHandler}
                validationSchema={validScehma}
                initialValues={initialFormValues}
                enableReinitialize={true}
            >
                <Form>
                    <h2 className="mb-5" style={{ fontFamily: 'serif', color: 'indianred' }}>Update Users</h2>

                    <div className="form-group">
                        <label htmlFor="">Name</label>
                        <Field
                            type="text"
                            name="name"
                            id=""
                            className="form-control"
                        />
                        <ErrorMessage name="name" className="text-danger" component="span" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">desc</label>
                        <Field
                            type="textarea"
                            name="desc"
                            id=""
                            className="form-control"
                        />
                        <ErrorMessage name="desc" className="text-danger" component="span" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">id</label>
                        <Field
                            type="text"
                            name="id"
                            id=""
                            className="form-control" disabled />
                        <ErrorMessage name="id" className="text-danger" component="span" />
                    </div>

                    <div className="form-group">
                        <button type="submit" className="btn btn-primary">Update</button>
                    </div>

                </Form>
            </Formik>
        </div>

    )
}

export default UpdateData
