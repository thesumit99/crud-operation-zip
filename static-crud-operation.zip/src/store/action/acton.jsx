export const actionHandler = (id) => {
    return {
        type: 'DELETE',
        payload: parseInt(id)
    }
}
export const addingHandler = (id) => {
    return {
        type: 'ADD',
        payload: id
    }
}
export const updatingDataHandler = (id) => {
    return {
        type: "UPDATE",
        payload: id
    }
}