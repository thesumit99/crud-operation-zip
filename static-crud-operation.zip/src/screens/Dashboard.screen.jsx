import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { actionHandler } from '../store/action/acton'
import { reducerHandler } from '../store/reducer/reducerHandler'
import AddData from './AddData'
import UpdateData from './UpdateData'
import { useTable } from 'react-table'
import styled from 'styled-components'



const Styles = styled.div`
table {
  width: 100%;
  border-spacing: 0;
  border: 1px solid black;
  tr {
    :last-child {
      td {
        border-bottom: 0;
      }
    }
  }
  th,
  td {
    margin: 0;
    padding: 1rem;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
    :last-child {
      border-right: 0;
    }
  }
}
`



function Table({ columns, data }) {
    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } = useTable({ columns, data })

    // Render Data Table UI
    return (
        <table {...getTableProps()}>
            <thead>
                {headerGroups.map(headerGroup => (
                    <tr {...headerGroup.getHeaderGroupProps()}>
                        {headerGroup
                            .headers
                            .map(column => (
                                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                            ))}
                    </tr>
                ))}
            </thead>
            <tbody {...getTableBodyProps()}>
                {rows.map((row, i) => {
                    prepareRow(row);
                    return (
                        <tr {...row.getRowProps()}>
                            {row
                                .cells
                                .map(cell => {
                                    return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                })}
                        </tr>
                    )
                })}
            </tbody>
        </table>
    )
}

const Dashboard = () => {
    const [displayData, setDisplayData] = useState([])
    let dispatch = useDispatch()
    let myState = useSelector(state => state.reducerHandler.value)

    const arr = () => {
        return 'sumit'
    }

    const LoadData = () => {
        setDisplayData(myState)
    }
    const deleteData = (id) => {
        console.log("iddddddddddddddddddds", id);
        dispatch(actionHandler(id))
    }
    useEffect(() => {
        LoadData()
    }, [deleteData, UpdateData, AddData])


    // ..............................


    const data = displayData
    console.log(displayData);
    const columns = [
        {
            Header: 'ID',
            accessor: 'id'
        }, {
            Header: 'Name',
            accessor: 'name'
        }, {
            Header: 'Descreption',
            accessor: 'desc'
        }, {
            Header: 'Status',
            accessor: 'update',
            Cell: e => {
                const ObData = e.row.original.id
                console.log("000000000000123", ObData);
                return (
                    <div className="d-flex">
                        <Link className="mr-4" to={`/update/${parseInt(ObData)}`}><i class="fas fa-edit"></i></Link>
                        <Link className="" onClick={() => deleteData(parseInt(ObData))}><i class="fas fa-trash"></i></Link>
                    </div>)
            }
        }
    ]
    console.log("<><><><><><>", columns);
    //....................



    return (


        <Styles className="m-5">
            <Link className="mb-3 float-right btn btn-success" to="/adding">ADD</Link>
            <Table
                data={data}
                columns={columns}
            />
        </Styles>
        // <div className="container mt-5">
        //     <h1 style={{ fontFamily: 'serif', color: 'indianred' }}>All Users</h1>

        //     <div style={{ borderRadius: 10 }}>
        //         <table className="table table-bordered" style={{ borderRadius: "10" }}>
        //             <thead>
        //                 <tr>
        //                     <th className="text-center">Id</th>
        //                     <th className="text-center">Firstname</th>
        //                     <th className="text-center">Description</th>
        //                     <th className="text-center">Action</th>
        //                 </tr>
        //             </thead>
        //             <tbody>
        //                 {
        //                     displayData.map((Data) => {
        //                         return (

        //                             <tr>
        //                                 <td className="text-center">{Data.id}</td>
        //                                 <td className="text-center">{Data.name}</td>
        //                                 <td>{Data.desc}</td>
        //                                 <td className="d-flex">
        //                                     <Link className="btn btn-outline-secondary text-center" to={`/update/${Data.id}`}>update</Link>
        //                                 </td>
        //                             </tr>
        //                         )
        //                     })
        //                 }
        //             </tbody>

        //         </table>
        //     </div>
        // </div>
    )
}

export default Dashboard
