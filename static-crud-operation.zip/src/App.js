import React from 'react'
import { Route, Switch } from 'react-router-dom'
import Dashboard from './screens/Dashboard.screen'
import AddData from './screens/AddData'
import UpdateData from './screens/UpdateData'

const App = () => {
  return (
    <Switch>
      <Route exact path="/">
        <Dashboard />
      </Route>
      <Route exact path="/adding">
        <AddData />
      </Route>
      <Route exact path="/update/:id">
        <UpdateData />
      </Route>
    </Switch>
  )
}

export default App
